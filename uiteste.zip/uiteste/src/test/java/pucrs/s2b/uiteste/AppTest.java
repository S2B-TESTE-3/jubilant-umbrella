package pucrs.s2b.uiteste;

import static org.junit.Assert.*;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AppTest {
	@Test
	public void giveGooglePageWhenSearchingForWikipediaThenWikipediaSearchBoxAppears() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\teste\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("https://www.google.com.br/");
		WebElement element = driver.findElement(By.name("q"));
		element.sendKeys("wikipedia");
		element.submit();
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement messageElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("nqsbq")));
		
		
		assertNotNull(messageElement);
		
		driver.close();
	}
	
	@Test
	public void giveWhenThen() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\teste\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("https://www.metric-conversions.org/pt-br/comprimento/milhas-em-quilometros.htm");
		WebElement element = driver.findElement(By.id("argumentConv1"));
		element.sendKeys("10");
		element.submit();
		
		/*WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement messageElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("nqsbq")));
		
		
		assertNotNull(messageElement);*/
		
		WebElement outElement = driver.findElement(By.id("answer"));
		double actual = Double.parseDouble(outElement.getText().split("=")[1].replace("km", ""));
		double expected = 16.09;
		
		assertEquals(expected, actual, .1);
		
		driver.close();
	}
}
